package TowerDefense;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import TowerDefense.entities.Bullet;
import TowerDefense.entities.enemies.Boss;
import TowerDefense.entities.enemies.Enemy;
import TowerDefense.entities.enemies.NormalEnemy;
import TowerDefense.entities.enemies.SmallEnemy;
import TowerDefense.entities.enemies.TankerEnemy;
import TowerDefense.entities.terrains.Terrain;
import TowerDefense.entities.towers.Tower;
import TowerDefense.entities.towers.MachineGun;
import TowerDefense.entities.towers.MiniGun;
import TowerDefense.entities.towers.MissileLauncher;


public final class Config {
//Static fields	
  //UI settings
	//FRAME
		public static final int MAX_FPS = 60;
		public static final int SCREEN_WIDTH = 1366;
		public static final int SCREEN_HEIGHT = 768;
	//Color
		public static final Color TRANS_WHITE = new Color(255, 255, 255, 150);
		public static final Color LIGHT_GRAY = new Color(200, 200, 200);
	//FONT
		public static final Font gameFont = new Font("Dialog", Font.PLAIN, 40);
		public static final Font enityFont = new Font(Font.MONOSPACED, Font.PLAIN, 24);
	//GRID
	    public static final int GRID_X = 0 ;
	    public static final int GRID_Y = 0 ;
	    public static final int GRID_HEIGHT = 640 ;
	    public static final int GRID_WIDTH = 1088 ;
    //INFO
	    public static final int INFO_X = 0 ;
	    public static final int INFO_Y = 640 ;
	    public static final int INFO_HEIGHT = 128 ;
	    public static final int INFO_WIDTH = 1088 ;
    //LEVEL
	    public static final int LEVEL_X = 20 ;
	    public static final int LEVEL_Y = 700 ;
    //LIVES
	    public static final int LIVES_X = 380 ;
	    public static final int LIVES_Y = 700 ;
    //CASH
	    public static final int CASH_X = 740 ;
	    public static final int CASH_Y = 700 ;
	//INFO OF ENTITY
	    public static final int INFO_ENTITY_X = 1088 ;
	    public static final int INFO_ENTITY_Y = 180 ;
	    public static final int INFO_ENTITY_WIDTH = 278 ;
	    public static final int INFO_ENTITY_HEIGHT = 390 ;
	    public static final int INFO_IMAGE_X = 1160 ;
	    public static final int INFO_IMAGE_Y = 196 ;
	    public static final int ATTRIBUTES_X = 1108 ;
	    public static final int NAME_Y = 350 ;
	    //Tower
	    public static final int DAMAGE_Y = 380 ;
	    public static final int RANGE_Y = 410 ;
	    public static final int F_RATE_Y = 440 ;
	    public static final int PRICE_Y = 470 ;
	    //Enemy
	    public static final int SPEED_ENEMY_Y = 440 ;
	    public static final int LEVEL_ENEMY_Y = 470 ;
	    public static final int HP_ENEMY_Y = 500 ;
	//UPGRADE / SELL BUTTON
	    public static final int SELL_BUTTON_X = 1108 ;
	    public static final int SELL_BUTTON_Y = 500 ;
	    public static final int SELL_WIDTH = 80 ;
	    public static final int SELL_HEIGHT = 40 ;
	    public static final int UPGRADE_BUTTON_X = 1208 ;
	    public static final int UPGRADE_BUTTON_Y = 500 ;
	    public static final int UPGRADE_WIDTH = 120 ;
	    public static final int UPGRADE_HEIGHT = 40 ;
    //NEXT LEVEL BUTTON
	    public static final int NEXT_LEVEL_BUTTON_X = 1114 ;
	    public static final int NEXT_LEVEL_BUTTON_Y = 608 ;
	    public static final int NEXT_LEVEL_BUTTON_WIDTH = 226 ;
	    public static final int NEXT_LEVEL_BUTTON_HEIGHT = 60 ;
    //MAIN MENU BUTTON
	    public static final int MAIN_MENU_BUTTON_X = 1114 ;
	    public static final int MAIN_MENU_BUTTON_Y = 688 ;
	    public static final int MAIN_MENU_BUTTON_WIDTH = 226 ; 
	    public static final int MAIN_MENU_BUTTON_HEIGHT = 60 ;
  //End UI settings
	
	//SHOP
	    public static final int SHOP_X = 1113;
	    public static final int SHOP_Y = 19;
	    public static final int SHOP_W = 220;
	    public static final int SHOP_H = 143;
	    public static final float SHOP_MINIGUN_X = 1114;
	    public static final float SHOP_MINIGUN_Y = 20;
	    public static final float SHOP_MACHINEGUN_X = 1191;
	    public static final float SHOP_MACHINEGUN_Y = 20;
	    public static final float SHOP_MISSILE_LAUNCHER_X = 1268;
	    public static final float SHOP_MISSILE_LAUNCHER_Y = 20;	    
	    public static List<Tower> SHOP = new ArrayList<Tower>();
	    
	//BANNER
	    public static Image WIN_BANNER;
	    public static Image LOSE_BANNER;
	
//Methods
	public static void load() {
		Toolkit toolkit = Toolkit.getDefaultToolkit(); 
		//load terrain images
			for (int i = 0; i < Terrain.TERRAIN_IMG.length; ++i) { 
				Terrain.TERRAIN_IMG[i] = toolkit.getImage("data\\img\\terrain\\"+i+".png");
			}
			for (int i = 0; i < Terrain.TERRAIN_MOUTAIN_IMG.length; ++i) { 
				Terrain.TERRAIN_MOUTAIN_IMG[i] = toolkit.getImage("data\\img\\terrain\\"+"tile"+i+".png");
			}
		// load menu
			Menu.MAP1_IMG = toolkit.getImage("data\\img\\menu\\MAP_1.png");
			Menu.MAP2_IMG = toolkit.getImage("data\\img\\menu\\MAP_2.png");
			Menu.MAP3_IMG = toolkit.getImage("data\\img\\menu\\MAP_3.png");
			Menu.EXIT_BUTTON_IMG = toolkit.getImage("data\\img\\menu\\EXIT_BUTTON.png");
			Menu.BACK_GROUND_IMG = toolkit.getImage("data\\img\\menu\\BACK_GROUND_IMG.png");
		//load tower images
			Tower.TOWER_BASE_IMG = toolkit.getImage("data\\img\\tower\\TowerBase.png");
			Tower.MINIGUN1_IMG = toolkit.getImage("data\\img\\tower\\MiniGun1.png");
			Tower.MINIGUN2_IMG = toolkit.getImage("data\\img\\tower\\MiniGun2.png");
			Tower.MINIGUN_EFFECT_IMG = toolkit.getImage("data\\img\\tower\\Effect1.png");
			Tower.MACHINEGUN1_IMG = toolkit.getImage("data\\img\\tower\\MachineGun1.png");
			Tower.MACHINEGUN2_IMG = toolkit.getImage("data\\img\\tower\\MachineGun2.png");
			Tower.MACHINEGUN_EFFECT_IMG = toolkit.getImage("data\\img\\tower\\Effect2.png");
			Tower.MISSILE_LAUNCHER1_IMG = toolkit.getImage("data\\img\\tower\\Missile1.png");
			Tower.MISSILE_LAUNCHER2_IMG = toolkit.getImage("data\\img\\tower\\Missile2.png");
			Tower.MISSILE_LAUNCHED_IMG = toolkit.getImage("data\\img\\tower\\MLaunched.png");
		//load bullet images
			Bullet.MINIGUN_BULLET = toolkit.getImage("data\\img\\bullet\\Bullet1.png");
			Bullet.MACHINEGUN_BULLET = toolkit.getImage("data\\img\\bullet\\Bullet2.png");
			Bullet.MISSILE1 = toolkit.getImage("data\\img\\bullet\\Missile1.png");
			Bullet.MISSILE2 = toolkit.getImage("data\\img\\bullet\\Missile2.png");
			Bullet.MISSILE_EFFECT = toolkit.getImage("data\\img\\bullet\\MissileEffect.png");
			Bullet.EXPLOSION_EFFECT = toolkit.getImage("data\\img\\bullet\\Explosion.png");
		//load enemy images
			Enemy.NORMAL_ENEMY_IMG = toolkit.getImage("data\\img\\enemy\\NormalEnemy.png");
			Enemy.SMALL_ENEMY_IMG = toolkit.getImage("data\\img\\enemy\\SmallEnemy.png");
			Enemy.TANKER_BODY_ENEMY_IMG = toolkit.getImage("data\\img\\enemy\\TankerBody.png");
			Enemy.TANKER_HEAD_ENEMY_IMG = toolkit.getImage("data\\img\\enemy\\TankerHead.png");
			Enemy.BOSS_ENEMY_IMG = toolkit.getImage("data\\img\\enemy\\Boss.png");
		//load win, lose banner
			WIN_BANNER = toolkit.getImage("data\\img\\win.png");
			LOSE_BANNER = toolkit.getImage("data\\img\\lose.png");
		//load shop
			SHOP.add(new MiniGun(SHOP_MINIGUN_X, SHOP_MINIGUN_Y, 1));
			SHOP.add(new MiniGun(SHOP_MINIGUN_X, SHOP_MINIGUN_Y+77, 2));
			SHOP.add(new MachineGun(SHOP_MACHINEGUN_X, SHOP_MACHINEGUN_Y, 1));
			SHOP.add(new MachineGun(SHOP_MACHINEGUN_X, SHOP_MACHINEGUN_Y+77, 2));
			SHOP.add(new MissileLauncher(SHOP_MISSILE_LAUNCHER_X, SHOP_MISSILE_LAUNCHER_Y, 1));
			SHOP.add(new MissileLauncher(SHOP_MISSILE_LAUNCHER_X,SHOP_MISSILE_LAUNCHER_Y+77,2));
	}
	
	//Get maps: 10x17 (rowsXcolumns)
		public static int[][] get_MAP_1() {
			int[][] testMap = {
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
	    	{ 0, 0, 0, 0, 0, 0, 0, 3, 1, 1, 1, 4, 0, 0, 0, 0, 0},
	    	{ 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 2, 0, 0, 0, 0, 0},
	    	{ 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 2, 0, 0, 0, 0, 0},
	    	{ 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 2, 0, 0, 0, 0, 0},
	    	{-1, 1, 1, 1, 1, 1, 1, 5, 0, 8, 1, 7, 0, 0, 0, 0, 0},
	    	{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0},
	    	{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 1, 1, 1, 1, 1, 1,-2},
	    	{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
	    	{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},};
			return testMap;
		}
		public static int[][] get_MAP_2() {
			int[][] testMap = {
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
			{ 0, 0, 0, 0, 0, 0, 3, 1, 1, 1, 1, 4, 0, 0, 0, 0, 0},
			{ 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0},
			{ 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 6, 1, 1, 1, 1,-2},
			{-1, 1, 4, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
			{ 0, 0, 2, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
			{ 0, 0, 2, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
			{ 0, 0, 6, 1, 1, 1, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},};
			return testMap;
		}
		public static int[][] get_MAP_3() {
			int[][] testMap = {
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
			{ 0, 0, 0, 0, 0, 0, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1,-2},
			{ 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
			{ 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
			{ 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
			{ 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
			{ 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
			{-1, 1, 1, 1, 1, 1, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},};
			return testMap;
		}
		/*
		 * Officially displaying map
		 * It is globally accessible map, for enemies to utilize in order to move 
		 */
		public static int[][] MAP;
		
	//Get enemies at a specific level
		public static Queue<Enemy> get_ENEMIES_LEVEL(int level) {
			Queue<Enemy> lv = new LinkedList<Enemy>();
			switch (level) {
			case 1:
				for (int i = 0; i<10; i++)
					lv.add(new NormalEnemy(0,0,0));
				return lv;
			
			case 2:
				for (int i = 0; i<5; i++)
					lv.add(new NormalEnemy(0,0,1));
				
				for (int i = 0; i<5; i++)
					lv.add(new SmallEnemy(0,0,0));
		
				return lv;
				
			case 3:
				for (int i = 0; i<5; i++)
					lv.add(new NormalEnemy(0,0,2));
				lv.add(new TankerEnemy(0,0,1));
				for (int i = 0; i<4; i++)
					lv.add(new SmallEnemy(0,0,0));
				lv.add(new Boss(0,0,0));
				return lv;
				
			case 4:
				lv.add(new TankerEnemy(0,0,1));
				for (int i = 0; i<5; i++)
					lv.add(new NormalEnemy(0,0,2));
				lv.add(new TankerEnemy(0,0,1));
				for (int i = 0; i<4; i++)
					lv.add(new SmallEnemy(0,0,0));
				return lv;
				
			case 5:
				lv.add(new Boss(0,0,1));
				return lv;
				
			case 6:
				lv.add(new TankerEnemy(0,0,2));
				for (int i = 0; i<5; i++)
					lv.add(new NormalEnemy(0,0,3));
				lv.add(new TankerEnemy(0,0,1));
				for (int i = 0; i<4; i++)
					lv.add(new SmallEnemy(0,0,1));
				return lv;
				
			case 7:
				lv.add(new TankerEnemy(0,0,3));
				for (int i = 0; i<5; i++)
					lv.add(new NormalEnemy(0,0,2));
				lv.add(new TankerEnemy(0,0,3));
				for (int i = 0; i<4; i++)
					lv.add(new SmallEnemy(0,0,2));
				return lv;
				
			case 8:
				lv.add(new Boss(0,0,2));
				for (int i = 0; i<4; i++)
					lv.add(new SmallEnemy(0,0,2));
				return lv;
				
			case 9:
				lv.add(new Boss(0,0,2));
				for (int i = 0; i<4; i++)
					lv.add(new NormalEnemy(0,0,2));
				return lv;
				
			case 10:
				lv.add(new Boss(0,0,2));
				for (int i = 0; i<2; i++)
					lv.add(new TankerEnemy(0,0,3));
				return lv;
				
			case 11:
				lv.add(new Boss(0,0,10));
				return lv;
				
			default:
				return null;
			}
		}
}
