package TowerDefense;

import java.awt.event.MouseEvent;
import java.util.LinkedList;
import java.util.List;
import TowerDefense.entities.AbstractEntity;
import TowerDefense.entities.terrains.*;
import TowerDefense.entities.towers.*;
import TowerDefense.sound.Sound;
import TowerDefense.entities.enemies.*;

public class GameField {
//Attributes: default accessibility for GameStage to manipulate easily
	private boolean playing = true;
	//Player
		Player player;
	//Shop
		List<Tower> shop;
	//Entities
		Terrain[][] map;
			Spawner spawner;
			Target target;
		List<Tower> towers;				//Using LinkedList instead of ArrayList is preferable
		List<Enemy> enemies;			//since we don't need direct element access but we need fast removal
		AbstractEntity clickedEntity;	// a Tower that was clicked by player
		AbstractEntity hoveredEntity;	// a Tower or an Enemy that was clicked by player
	
//Methods
	//Constructor
	public GameField(int mapID) {
		player = new Player();
		shop = Config.SHOP;
		towers = new LinkedList<Tower>();
		enemies = new LinkedList<Enemy>();
		//load map
		map = new Terrain[10][17];
		loadMap(mapID);
	}

	//Operations
		//MouseEvent processing operations' implementation 
		/**selectEntityIf_Hover: 
		 * @param MouseEvent e
		 * Check what entity that event e is targeting to
		 * Set hoveredEntity as that entity
		 * Otherwise set to null 
		 */
		public void selectEntityIf_Hover(MouseEvent e) {
			int mouseX = e.getX();
			int mouseY = e.getY();
			//if mouse's on grid
			if (mouseX < Config.GRID_WIDTH && mouseY < Config.GRID_HEIGHT) {
				int i = mouseY/64;
				int j = mouseX/64;
				//check if mouse was on mountain
				if (map[i][j] instanceof Mountain) {
					Mountain mountain = (Mountain)map[i][j];
					hoveredEntity = mountain.getOccupiedTower();
				}
				//else mouse was on the road -> check if mouse was on an enemy
				else {
					for (Enemy enemy : enemies) {
						if (mouseInRect(mouseX, mouseY, (int)enemy.getPosX(), (int)enemy.getPosY(), 64, 64)) {
							hoveredEntity = enemy; 
							break;
						}
					}
				}
			} else
			//if mouse's on shop
			if (mouseInRect(mouseX, mouseY, Config.SHOP_X, Config.SHOP_Y, Config.SHOP_W, Config.SHOP_W)) {
				for (Tower tower : shop) {
					if (mouseInRect(mouseX, mouseY, (int)tower.getPosX(), (int)tower.getPosY(), 64, 64)) 
					{
						hoveredEntity = tower; 
						break;
					}
				}				
			} 
			else hoveredEntity = null;
		}
		/**selectEntityIf_Click:
		 * @param MouseEvent e
		 * Check what entity that event e is targeting to
		 * Set clickedEntity as that entity
		 */
		public void selectEntityIf_Click(MouseEvent e) {
			int mouseX = e.getX();
			int mouseY = e.getY();
			//if mouse's on grid
			if (mouseX < Config.GRID_WIDTH && mouseY < Config.GRID_HEIGHT) {
				//check if mouse was on a tower
				int i = mouseY/64;
				int j = mouseX/64;
				if (map[i][j] instanceof Mountain) {
					Mountain mountain = (Mountain)map[i][j];
					clickedEntity = mountain.getOccupiedTower();
				}
			} else
			//if mouse's on shop
			if (mouseInRect(mouseX, mouseY, Config.SHOP_X, Config.SHOP_Y, Config.SHOP_W, Config.SHOP_W)) {
				for (Tower tower : shop) {
					if (mouseInRect(mouseX, mouseY, (int)tower.getPosX(), (int)tower.getPosY(), 64, 64)) {
						//if player had enough cash
						if (player.getCash() - tower.getPrice() >= 0 )
							clickedEntity = tower; 
						break;
					}
				}
			}
		}
		/**manipulateClickedEntity:
		 * By the time this method is called, clickedEntity is a tower that player selected  
		 * @param MouseEvent e 
		 * Check what event e is doing to clickedEntity
		 * It can be buying/selling/upgrading a tower or deselecting the tower
		 */
		public void manipulateClickedEntity(MouseEvent e) {
			int mouseX = e.getX();
			int mouseY = e.getY();
			//if mouse's on grid 
			if (mouseX < Config.GRID_WIDTH && mouseY < Config.GRID_HEIGHT) {
				int i = mouseY/64;
				int j = mouseX/64;
				//check if mouse was on an unOccupied Mountain
				if (map[i][j] instanceof Mountain) {
					Mountain mountain = (Mountain)map[i][j];
					if (mountain.isOccupied())
						clickedEntity = mountain.getOccupiedTower();
					//if not occupied -> buy tower
					else player.buyTower((Tower)clickedEntity, mountain, towers);
				}
			}
			//check if mouse on buttons
			else if (mouseInRect(mouseX, mouseY, Config.UPGRADE_BUTTON_X, Config.UPGRADE_BUTTON_Y, Config.UPGRADE_WIDTH, Config.UPGRADE_HEIGHT)) {
                player.playerUpgradeTower((Tower)clickedEntity);
            }
            else if (mouseInRect(mouseX, mouseY, Config.SELL_BUTTON_X, Config.SELL_BUTTON_Y, Config.SELL_WIDTH, Config.SELL_HEIGHT)) {
                int j = (int) clickedEntity.getPosX() / 64;
                int i = (int) clickedEntity.getPosY() / 64;
                if (i < 10 && j < 17)
                player.playerRemoveTower((Tower)clickedEntity, (Mountain)map[i][j], towers);
            }
			//deselect
            clickedEntity = null;
		}
		/*
		 * 
		 */
		public void checkMainButtons(MouseEvent e) {
			int mouseX = e.getX();
			int mouseY = e.getY();
			//Next level button
			if (mouseInRect(mouseX, mouseY, 
				Config.NEXT_LEVEL_BUTTON_X, Config.NEXT_LEVEL_BUTTON_Y, 
				Config.NEXT_LEVEL_BUTTON_WIDTH, Config.NEXT_LEVEL_BUTTON_HEIGHT)) 
			{
					nextLevel();
			}
			//Main menu button
			if (mouseInRect(mouseX, mouseY, 
				Config.MAIN_MENU_BUTTON_X, Config.MAIN_MENU_BUTTON_Y, 
				Config.MAIN_MENU_BUTTON_WIDTH, Config.MAIN_MENU_BUTTON_HEIGHT)) 
			{
					playing = false;
					Sound.Click.play();
			}
		}
		//End MouseEvent processing operations' implementation
		
		
		public void nextLevel() {
			//can only start next level when there is no approaching enemy & all current enemies are gone 
			if (enemies.isEmpty() && !spawner.hasApproachingEnemies() && player.isAlive()) {
				player.nextLevel();
				spawner.setApproachingEnemies(Config.get_ENEMIES_LEVEL(player.getLevel()));
				//if there is no more enemy -> stop the game, player wins
				if (spawner.getApproachingEnemies() == null)
					playing = false;
				//play SFX
				Sound.Click.play();
			}
		}
		
		
		/**enitiesInteract: called in game loop (or GameStage.play())
		 * @param elapsedTime
		 * Call interactive methods of enemies and towers from lists
		 * such as tower.shoot(enemy), enemy.move(), if (!enemy.isAlive()) list.remove(enemy)...
		 */
		public void enitiesInteract(long elapsedTime) {
			//spawner
				if (spawner.hasApproachingEnemies()) {
					spawner.spawnEnemy(elapsedTime, enemies);
				}
			//towers
				for (Tower t : towers) {
					t.shootEnemy(enemies, elapsedTime);
				}
			//enemies
				//use for-index loop for safe removal, using for-each loop would cause exception
				for (int i = 0; i < enemies.size(); ++i) {
					while (!enemies.get(i).isAlive()) {
						if (!enemies.get(i).isInRect((int)target.getPosX(), (int)target.getPosY(), 64, 64))
							player.receiveReward(enemies.get(i));
						enemies.remove(i);
						if (i >= enemies.size()) return;
					}
					enemies.get(i).move(elapsedTime);
				}
			//check if player lose
				if (!player.isAlive()) {
					playing = false;
				}
		}
		
	
	//helper methods
		private boolean mouseInRect(int mouseX, int mouseY, int x, int y, int w, int h) {
			return (x < mouseX&&mouseX < x+w) && (y < mouseY&&mouseY < y+h);
		}
		
		private void loadMap(int mapID) {
			//Set Config.MAP as map
			switch (mapID) {
			case 1:
				Config.MAP = Config.get_MAP_1();
				break;
			case 2:
				Config.MAP = Config.get_MAP_2();
				break;
			case 3:
				Config.MAP = Config.get_MAP_3();
				break;
			default:break;
			}
			//load from Config.MAP
			int[][] a = Config.MAP;
			for (int i = 0; i < 10; ++i) {
				for (int j = 0; j < 17; ++j) {
					//target
					if (a[i][j] == -2) {
						map[i][j] = new Target(j*64, i*64, 1, player);
						target = (Target)map[i][j];
						Enemy.ENEMY_TARGET = target;
					}
					//spawner //spawner and target have default image id as 1 (vertical road image)
					else if (a[i][j] == -1) {
						map[i][j] = new Spawner(j*64, i*64, 1);
						spawner = (Spawner)map[i][j];
					}
					//mountain
					else if (a[i][j] == 0) {
						map[i][j] = new Mountain(j*64, i*64, 0);
					}
					//road
					else if (1 <= a[i][j] && a[i][j] <= Terrain.TERRAIN_IMG.length) {
						map[i][j] = new Road(j*64, i*64, a[i][j]);
					}
				}
			}
		}
		
	//getters & setters
		public boolean isPlaying() {return playing;}
		public void setPlaying(boolean playing) {this.playing = playing;}
}
