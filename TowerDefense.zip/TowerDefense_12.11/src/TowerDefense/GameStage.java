package TowerDefense;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.MouseEvent;
import javax.swing.JPanel;
import TowerDefense.entities.enemies.Enemy;
import TowerDefense.entities.terrains.Terrain;
import TowerDefense.entities.towers.Tower;
import TowerDefense.sound.Sound;

public class GameStage extends JPanel{
//Attributes	
	private GameField field;
	
//Methods	
	//Constructor
	public GameStage(int mapID) {
		this.setSize(Config.SCREEN_WIDTH, Config.SCREEN_HEIGHT);
		//enable events to processMouseEvent
		this.enableEvents(MouseEvent.MOUSE_EVENT_MASK);
		this.enableEvents(MouseEvent.MOUSE_MOTION_EVENT_MASK); 
		//Create GameField
		field = new GameField(mapID);		
	}
	
	//Operations
		
		//Play the game ~ enter the game loop
		public void play() {
			long elapsedTime;
			long now = System.currentTimeMillis();
	        Sound.BackGround.loop();
			
			while (field.isPlaying()) {
				//compute elapsedTime
					elapsedTime = System.currentTimeMillis() - now;
					now = System.currentTimeMillis();
				//interactions between entities after time elapsed 
					field.enitiesInteract(elapsedTime);
				//repaint screen
					repaint();
				try {
					Thread.sleep(1000/Config.MAX_FPS);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			
			Sound.BackGround.stop();
			displayGameResult(this.getGraphics());
		}
		
		//display the result of the game
		private void displayGameResult(Graphics renderer) {
			if (field.player.isAlive() && field.player.getLevel() > 11) {
				//render winning banner //this wait until the whole image is rendered, then exit the loop
				while (!renderer.drawImage(Config.WIN_BANNER, 284, 205, null)) {}
				//play sound
	            Sound.Win.play();
			}
			else {
				//render loosing banner //this wait until the whole image is rendered, then exit the loop
				while (!renderer.drawImage(Config.LOSE_BANNER, 284, 205, null)) {}
				//play sound
	            Sound.GameOver.play();
			}
			//pause for a moment before going back to main menu
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		//Process mouse event
		@Override
		protected void processMouseEvent(MouseEvent e) {
			if (e.getID() == MouseEvent.MOUSE_PRESSED) {
				//check if mouse was on main buttons, and if so, do certain operations 
				field.checkMainButtons(e);
				//check if mouse was on entity
				if (field.clickedEntity == null) 
					field.selectEntityIf_Click(e);
				else 
					field.manipulateClickedEntity(e);
			}
	    }
		@Override
		protected void processMouseMotionEvent(MouseEvent e) {
			if (e.getID() == MouseEvent.MOUSE_MOVED) {
				field.selectEntityIf_Hover(e);
			}
		}
		
		
		@Override
		protected void paintComponent(Graphics renderer) {
			super.paintComponent(renderer);
			renderer.setColor(Config.LIGHT_GRAY);
			renderer.fillRect(0, 0, Config.SCREEN_WIDTH, Config.SCREEN_HEIGHT);
			renderer.setColor(Color.BLACK);
			renderShop(renderer);
			renderGameField(renderer);
			renderUIFrame(renderer);
		}
			//Sub-methods that is called in paint to render different parts of the screen 
			private void renderUIFrame(Graphics renderer) {
				//Grid //comment this out to remove grid
			        /*for (int x = 0; x <Config.GRID_WIDTH; x += 64 ) {
			            for (int y = 0; y <Config.GRID_HEIGHT; y += 64) {
			                renderer.drawRect(x, y, 64, 64);
			            }
			        }*/
				renderer.drawRect(Config.GRID_X, Config.GRID_Y, Config.GRID_WIDTH, Config.GRID_HEIGHT);
		        //Info Below Grid
		        renderer.drawRect(Config.INFO_X, Config.INFO_Y, Config.INFO_WIDTH, Config.INFO_HEIGHT);
		        	renderer.setFont(Config.gameFont);
		        	//level
		            	renderer.drawString("Level: " + field.player.getLevel(), Config.LEVEL_X, Config.LEVEL_Y);
		            //lives
		                renderer.drawString("Lives: " + field.player.getLives(), Config.LIVES_X, Config.LIVES_Y);
		            //cash
		                renderer.drawString("Cash: " + field.player.getCash(), Config.CASH_X, Config.CASH_Y);
		        //Info of entity
		            renderer.drawRect(Config.INFO_ENTITY_X, Config.INFO_ENTITY_Y, Config.INFO_ENTITY_WIDTH, Config.INFO_ENTITY_HEIGHT);
	            //Next Level button
	                renderer.drawRect(Config.NEXT_LEVEL_BUTTON_X, Config.NEXT_LEVEL_BUTTON_Y, Config.NEXT_LEVEL_BUTTON_WIDTH, Config.NEXT_LEVEL_BUTTON_HEIGHT );
	                renderer.drawString("Next Level", Config.NEXT_LEVEL_BUTTON_X+10, Config.NEXT_LEVEL_BUTTON_Y+50);
	            //Main menu button
	                renderer.drawRect(Config.MAIN_MENU_BUTTON_X, Config.MAIN_MENU_BUTTON_Y, Config.MAIN_MENU_BUTTON_WIDTH, Config.MAIN_MENU_BUTTON_HEIGHT );
	                renderer.drawString("Main Menu", Config.MAIN_MENU_BUTTON_X+10, Config.MAIN_MENU_BUTTON_Y+50);
		    }
			private void renderShop(Graphics renderer) {
				//renderer.drawRect(Config.SHOP_X, Config.SHOP_Y, Config.SHOP_W, Config.SHOP_H);
				for (Tower tower : field.shop)
					tower.draw(renderer);
				renderer.drawRect((int)Config.SHOP_MINIGUN_X, (int)Config.SHOP_MINIGUN_Y, 64, 64);
				renderer.drawRect((int)Config.SHOP_MINIGUN_X, (int)Config.SHOP_MINIGUN_Y+77, 64, 64);
				renderer.drawRect((int)Config.SHOP_MACHINEGUN_X, (int)Config.SHOP_MACHINEGUN_Y, 64, 64);
				renderer.drawRect((int)Config.SHOP_MACHINEGUN_X, (int)Config.SHOP_MACHINEGUN_Y+77, 64, 64);
				renderer.drawRect((int)Config.SHOP_MISSILE_LAUNCHER_X, (int)Config.SHOP_MISSILE_LAUNCHER_Y, 64, 64);
				renderer.drawRect((int)Config.SHOP_MISSILE_LAUNCHER_X, (int)Config.SHOP_MISSILE_LAUNCHER_Y+77, 64, 64);
			}
			private void renderGameField(Graphics renderer) {
				//Render Terrains
				for (Terrain[] i : field.map) { //for-each loop
					for (Terrain j : i) {
						j.draw(renderer);
					}
				}
				//Render Enemies
				for (Enemy e : field.enemies) {
					e.draw(renderer);
				}
				//Render Towers
				for (Tower t : field.towers) {
					t.draw(renderer);
				}
				//Render clickedEntity
				if (field.clickedEntity != null) {
					field.clickedEntity.drawInfo(renderer);
					//draw tower attached to mouse if tower originated from shop
					if (field.clickedEntity.isInRect(Config.SHOP_X, Config.SHOP_Y, Config.SHOP_W, Config.SHOP_W)) {
						Point mouseCoordinate = this.getMousePosition();
						if (mouseCoordinate != null) {
							int mouseX = mouseCoordinate.x;
							int mouseY = mouseCoordinate.y;
							((Tower)field.clickedEntity).drawAttachedToMouse(renderer, mouseX, mouseY);
						}
					}
				} else
				//Render hoveredEntity
				if (field.hoveredEntity != null)
					field.hoveredEntity.drawInfo(renderer);
			}
		//End "paint"'s implementation
	//End Operations' implementation
}
