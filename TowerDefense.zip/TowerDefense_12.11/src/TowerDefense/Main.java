package TowerDefense;

import java.awt.Container;
import java.awt.Dimension;
import javax.swing.JFrame;

public class Main {
	private static JFrame frame;
	private static Menu mainMenu;	//a JPanel
	private static GameStage stage; //also a JPanel
	
//Methods
	private static void initialize() {
		//Initialize Config - settings and materials for the game
			Config.load();
		//Create window
			frame = new JFrame("Tower Defense - VTS");
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//Ensure the content of frame is 1366x768
			Container content = frame.getContentPane();
			Dimension mySize = new Dimension(Config.SCREEN_WIDTH, Config.SCREEN_HEIGHT);
            content.setPreferredSize(mySize);
            frame.pack();
	}
	
//main function
	public static void main(String[] args) {
		initialize();
		//Create main menu
		mainMenu = new Menu();
		frame.setContentPane(mainMenu);
		frame.setVisible(true);
		
		while (mainMenu.chooseMap() == true) {
			//create new GameStage according to choice
			int mapID = mainMenu.getSelectedOption();
			stage = new GameStage(mapID);
			frame.setContentPane(stage);
			frame.setVisible(true);
			//start playing
			stage.play();
			//end of game stage, back to main menu
			stage = null;
			frame.setContentPane(mainMenu);
			//set selected option back to initial state
			mainMenu.setSelectedOption(0);
		}
		
		frame.dispose();
	}
}
