package TowerDefense;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.MouseEvent;
import javax.swing.JPanel;

public class Menu extends JPanel {
//Static fields
	//img
		public static Image MAP1_IMG;
		public static Image MAP2_IMG;
		public static Image MAP3_IMG;
		public static Image EXIT_BUTTON_IMG;
		public static Image BACK_GROUND_IMG;
	//options
		private static int NULL = 0;
		private static int MAP_1 = 1;
		private static int MAP_2 = 2;
		private static int MAP_3 = 3;
		private static int EXIT = 4;
	
//Attributes
	private int selectedOption;
	
//Methods
	//Constructor
	public Menu() {
		this.setSize(Config.SCREEN_WIDTH, Config.SCREEN_HEIGHT);
		//enable events to processMouseEvent
		this.enableEvents(MouseEvent.MOUSE_EVENT_MASK);
		this.enableEvents(MouseEvent.MOUSE_MOTION_EVENT_MASK);
	}
	
	//Operations
	
		/* Keep displaying the menu until the player chose a map or exit
		 * Return true  if player chose a map
		 * Return false if player chose "exit"
		 */
		public boolean chooseMap() {
			//loop until player chose a map or exit
			while (selectedOption == NULL) {
				repaint();
				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			return selectedOption != EXIT;
		}
		
		//Process mouse event
		@Override
		protected void processMouseEvent(MouseEvent e) {
			if (e.getID() == MouseEvent.MOUSE_PRESSED) {
				int mouseX = e.getX();
				int mouseY = e.getY();
				//map 1
				if (100 < mouseX&&mouseX < 100+300 && 200 < mouseY&&mouseY < 200+300) 
					selectedOption = MAP_1;
				//map 2
				else if (500 < mouseX&&mouseX < 500+300 && 200 < mouseY&&mouseY < 200+300)
					selectedOption = MAP_2;
				//map 3
				else if (900 < mouseX&&mouseX < 900+300 && 200 < mouseY&&mouseY < 200+300)
					selectedOption = MAP_3;
				//Exit button
				else if (500 < mouseX&&mouseX < 500+300 && 600 < mouseY&&mouseY < 600+100)
					selectedOption = EXIT;
			}
	    }
		@Override
		protected void processMouseMotionEvent(MouseEvent e) {
			if (e.getID() == MouseEvent.MOUSE_MOVED) {
				
			}
		}
		
		@Override
		public void paint(Graphics renderer) {
			renderer.setFont(Config.gameFont);
			//background
			renderer.drawImage( BACK_GROUND_IMG,0, 0, Config.SCREEN_WIDTH, Config.SCREEN_HEIGHT, null);
			//map 1
			renderer.drawString("MAP 1", 185, 180);
			renderer.fillRect(100-3, 200-3, 300+6, 300+6);
			renderer.drawImage( MAP1_IMG,100, 200, 300, 300, null);
			//map 2
			renderer.drawString("MAP 2", 585, 180);
			renderer.fillRect(500-3, 200-3, 300+6, 300+6);
			renderer.drawImage( MAP2_IMG,500, 200, 300, 300, null);
			//map 3
			renderer.drawString("MAP 3", 985, 180);
			renderer.fillRect(900-3, 200-3, 300+6, 300+6);
			renderer.drawImage( MAP3_IMG,900, 200, 300, 300, null); //edit map 3
			//exit
			renderer.drawImage( EXIT_BUTTON_IMG,500, 600, 300, 70, null);
			renderer.drawRect(500, 600, 300, 70);
		}
	
	//getters & setters
		public int getSelectedOption() {
			return selectedOption;
		}
		public void setSelectedOption(int selectedOption) {
			this.selectedOption = selectedOption;
		}
}
