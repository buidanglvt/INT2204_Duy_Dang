package TowerDefense;

import java.util.List;

import TowerDefense.entities.enemies.Enemy;
import TowerDefense.entities.terrains.Mountain;
import TowerDefense.entities.towers.Tower;
import TowerDefense.sound.Sound;

public class Player {
//Static fields
	
	
//Attributes
	private int cash;
	private int lives;
	private int level;
	
//Methods
	//Constructor
	public Player() {
		this.cash = 500;
		this.lives = 10;
		this.level = 0;
	}
	
	//Operations
		public void buyTower(Tower t, Mountain mountain, List<Tower> towers) {
			//only buy Tower originated from shop
			if (t.isInRect(Config.SHOP_X, Config.SHOP_Y, Config.SHOP_W, Config.SHOP_H)) {
				Tower newTower = t.clone();
				newTower.setPosX(mountain.getPosX());
				newTower.setPosY(mountain.getPosY());
				mountain.setOccupiedTower(newTower);
				towers.add(newTower);
				cash -= newTower.getPrice();
				Sound.PlacedTower.play();
			}
		}
		
		public void playerRemoveTower(Tower t , Mountain m , List <Tower> towers) {
			//only remove tower in grid, not in shop
			if (t.getPosX() < Config.GRID_WIDTH && t.getPosY() < Config.GRID_HEIGHT) {
		        cash += t.getPrice()* Tower.DEPRECIATION ;
		        towers.remove(t) ;
		        m.setOccupiedTower(null) ;
		        Sound.Click.play();
			}
	    }

	    public void playerUpgradeTower(Tower t) {
	    	//only upgrade tower in grid, not in shop
	    	if (t.getPosX() < Config.GRID_WIDTH && t.getPosY() < Config.GRID_HEIGHT && t.getType() == 1) {
	    		if (cash >= t.getUpgradeCost()) {
		            t.upgrade();
		            cash = cash - t.getUpgradeCost();
		            Sound.PlacedTower.play();
	    		}
            }
	    }
		
		public void receiveReward(Enemy e) {
			cash += e.getReward();
		}
	
	//getters & setters
		public int getCash() {return cash;}
		public void setCash(int cash) {this.cash = cash;}

		public int getLives() {return lives;}
		public void setLives(int lives) {this.lives = lives;}
		public boolean isAlive() {return lives > 0;}

		public int getLevel() {return level;}
		public void nextLevel() {this.level += 1;}
}
