package TowerDefense.entities;

import java.awt.Graphics;

public abstract class AbstractEntity implements GameEntity{
//Attributes
	protected float posX;
	protected float posY;

//Methods
	//Operations
	/**
	 * @param renderer
	 * draw the entity and its info
	 */
	public abstract void draw(Graphics renderer);
	public abstract void drawInfo(Graphics renderer);
	
	public boolean isInRect(int x, int y, int w, int h) {
		return (x < posX&&posX < x+w) && (y < posY&&posY < y+h);
	}
	
	/**
	 * @param AbstractEntity other
	 * @return distance between this entity and the other entity
	 */
	public float getDistance(AbstractEntity other) {
		float deltaX = posX - other.posX;
		float deltaY = posY - other.posY;
		return (float)Math.sqrt(deltaX*deltaX + deltaY*deltaY);
	}
	
	//getters & setters
		public float getPosX() {return posX;}
		public float getPosY() {return posY;}
		public void setPosX(float posX) {this.posX = posX;}
		public void setPosY(float posY) {this.posY = posY;}
}
