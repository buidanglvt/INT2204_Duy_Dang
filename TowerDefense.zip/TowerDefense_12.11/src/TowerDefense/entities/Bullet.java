package TowerDefense.entities;

import java.awt.Graphics;
import java.awt.Image;
import TowerDefense.entities.enemies.Enemy;

public class Bullet extends AbstractEntity {
//Static fields
	public static Image MINIGUN_BULLET;
	public static Image MACHINEGUN_BULLET;
	public static Image MISSILE1;
	public static Image MISSILE2;
	public static Image MISSILE_EFFECT;
	public static Image EXPLOSION_EFFECT;
	public static final float MINI_BULLET_VELOCITY = 500 ; //(pixels/s)
	public static final float MACHINE_BULLET_VELOCITY = 1000 ; //(pixels/s)
	public static final float MISSILE_VELOCITY = 300 ; //(pixels/s)
	public static final long MISSILE_EXPLOSION_TIME = 400 ; //millisecond
	
//Attributes
	private Image img;
	private float velocity;		//pixels/s
	private double AimAngle;	//radiant
	private long lastHitTime;	//millisecond
	private boolean visible;
	private boolean hitEffectOn;
	private Enemy target;
	
	//Constructor
	public Bullet (Image img, float posX, float posY, float velocity) {
		this.img = img;
		this.posX = posX ;
		this.posY = posY ;
		this.velocity = velocity;
		this.visible = false;
		this.hitEffectOn = false;
		this.lastHitTime = 1000;
	}
//Methods
	//Operations
		/**
		 * @param elapsedTime
		 * move the bullet as time passes
		 */
		public void move(long elapsedTime) {
			float vX = velocity * (float)Math.sin(Math.PI - AimAngle) + target.getvX();
			float vY = velocity * (float)Math.cos(Math.PI - AimAngle) + target.getvY();
			posX += vX*elapsedTime/1000 ;
			posY += vY*elapsedTime/1000 ;
		}
		
		public void setHitEffectOn(long elapsedTime) {
			lastHitTime += elapsedTime;
			hitEffectOn = true;
			if (lastHitTime > MISSILE_EXPLOSION_TIME) {
				hitEffectOn = false;
			}
		}
		
		@Override
		public void draw(Graphics renderer) {
			renderer.drawImage(img, (int)posX, (int)posY, null);
		}
		public void drawInfo(Graphics renderer) {} //do nothing
		
	
	//getters & setters
		public boolean isVisible() {return visible;}
		public void setVisible(boolean visible) {this.visible = visible;}
		
		public double getAimAngle() {return AimAngle;}
		public void setAimAngle(double aimAngle) {this.AimAngle = aimAngle;}
		
		public Enemy getTarget() {return target;}
		public void setTarget(Enemy target) {this.target = target;}
		
		public boolean isHitEffectOn() {return lastHitTime < MISSILE_EXPLOSION_TIME;}
		public void setHitEffectOn(boolean hitEffectOn) {this.hitEffectOn = hitEffectOn;}
		
		public long getLastHitTime() {return lastHitTime;}
		public void setLastHitTime(long lastHitTime) {this.lastHitTime = lastHitTime;}
}
