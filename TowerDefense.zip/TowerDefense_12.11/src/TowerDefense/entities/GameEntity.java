package TowerDefense.entities;

import java.awt.Graphics;

public interface GameEntity {
	static final int WIDTH = 64;
	static final int HEIGHT = 64;
	
	public abstract void draw(Graphics renderer);
	public abstract void drawInfo(Graphics renderer);
	
	public abstract boolean isInRect(int x, int y, int w, int h);
	
	public abstract float getPosX();
	public abstract float getPosY();
	public void setPosX(float posX);
	public void setPosY(float posY);
}
