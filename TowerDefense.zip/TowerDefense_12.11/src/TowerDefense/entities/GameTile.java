package TowerDefense.entities;

public interface GameTile extends GameEntity {
	
	
	
}
