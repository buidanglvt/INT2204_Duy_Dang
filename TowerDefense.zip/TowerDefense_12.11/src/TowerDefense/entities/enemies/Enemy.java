package TowerDefense.entities.enemies;

import java.awt.Graphics;
import java.awt.Image;
import TowerDefense.Config;
import TowerDefense.entities.AbstractEntity;
import TowerDefense.entities.terrains.Target;
import TowerDefense.entities.terrains.Terrain;

public abstract class Enemy extends AbstractEntity {
//Static fields
	//Images
		//Small Enemy
		public static Image SMALL_ENEMY_IMG;
		//Normal Enemy
		public static Image NORMAL_ENEMY_IMG;
		//Tanker Enemy
		public static Image TANKER_HEAD_ENEMY_IMG;
		public static Image TANKER_BODY_ENEMY_IMG ;
		//Boss Enemy
		public static Image BOSS_ENEMY_IMG;
	//Speed
		static float SMALLENEMY_SPEED = 130;	//pixels/s
		static float NORMALENEMY_SPEED = 100;
		static float TANKERENEMY_SPEED = 50;
		static float BOSSENEMY_SPEED = 50;
	//HP
		static int NORMAL_ENEMY_HP = 200;
		static int SMALL_ENEMY_HP = 100;
		static int TANKER_ENEMY_HP = 1000;
		static int BOSS_ENEMY_HP = 10000;
	//Enemy Reward
		static int NORMAL_ENEMY_REWARD = 20;
		static int SMALL_ENEMY_REWARD = 10;
		static int TANKER_ENEMY_REWARD = 100;
		static int BOSS_ENEMY_REWARD = 500;
	//Target
		public static Target ENEMY_TARGET;

//Attributes
	protected float vX;
	protected float vY;
	protected int healthPoint;
	protected double angle;
	protected int level;
	protected int reward;
	
//Methods
	//Constructor
	public Enemy(float posX, float posY, int level) {
		this.posX = posX;
		this.posY = posY;
		this.level = level;
	}
	
	//Operations
		/**
		 * @param elapsedTime
		 * move the enemy as time passes
		 */
		public void move(long elapsedTime) {
			int i = (int)(posY/64);
			int j = (int)(posX/64);
			switch (Config.MAP[i][j]) {
				case 3: //UP_RIGHT
					if (posY <= i*64 + 5 && vX == 0) {
						vX = -vY;
						vY = 0;
						angle = 0;
					}
					break;
				case 4: //RIGHT_DOWN
					if (vY == 0) {
						vY = vX;
						vX = 0;
						angle = Math.PI/2;
					}
					break;
				case 5: //RIGHT_UP
					if (vY == 0) {
						vY = -vX;
						vX = 0;
						angle = -Math.PI/2;
					}
					break;
				case 6: //DOWN_RIGHT
					if (vX == 0) {
						vX = vY;
						vY = 0;
						angle = 0;
				
					}
					break;
				case 7: //DOWN_LEFT
					if (vX==0) {
						vX = -vY;
						vY = 0;
						angle = Math.PI;
					}
					break;
				case 8 : //LEFT DOWN
					if (posX <= 64*j +5 && vY == 0){
						vY = -vX;
						vX = 0;
						angle = Math.PI/2;
					}
					break;
				case -2: //Reached the target
					setHP(0);
					ENEMY_TARGET.getPlayer().setLives(ENEMY_TARGET.getPlayer().getLives()-1);
					break;
				default: 
					break;
			}
			posX += vX*elapsedTime/1000;
			posY += vY*elapsedTime/1000;
		}
		
		public boolean isAlive() {
			return healthPoint > 0;
		}
		
		protected void drawAttributes(Graphics renderer){
			renderer.setFont(Config.enityFont);
			renderer.drawString("Speed: " + Math.abs(vX + vY), Config.ATTRIBUTES_X, Config.SPEED_ENEMY_Y);
			renderer.drawString("Level: " + this.level, Config.ATTRIBUTES_X, Config.LEVEL_ENEMY_Y);
			renderer.drawString("HP: " + this.healthPoint, Config.ATTRIBUTES_X, Config.HP_ENEMY_Y);
			renderer.drawImage(Terrain.TERRAIN_IMG[1], Config.INFO_IMAGE_X, Config.INFO_IMAGE_Y,128,128,null);
		}
		
	//abstract
		public abstract int getReward();
		@Override
		public abstract void draw(Graphics renderer);
		public abstract void drawInfo(Graphics renderer);
	
	//getters & setters
		public float getvX() {return vX;}
		public void setvX(float vX) {this.vX = vX;}

		public float getvY() {return vY;}
		public void setvY(float vY) {this.vY = vY;}

		public int getHP() {return healthPoint;}
		public void setHP(int healthPoint) {this.healthPoint = healthPoint;}
}
