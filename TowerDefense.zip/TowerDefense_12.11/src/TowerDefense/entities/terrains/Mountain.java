package TowerDefense.entities.terrains;

import java.awt.Graphics;
import java.util.Random;
import TowerDefense.entities.towers.Tower;

public class Mountain extends Terrain{
	static Random rand = new Random();
//Attributes
	private Tower occupiedTower;
	private int random_moutain =  rand.nextInt(14)+1;
	
//Methods
	public Mountain(float posX, float posY, int imgId) {
		this.posX = posX;
		this.posY = posY;
		this.imgId = imgId;
	}
	
	public void draw(Graphics renderer) {
		super.draw(renderer);
		if (random_moutain<=7)
		{
		renderer.drawImage(TERRAIN_MOUTAIN_IMG[random_moutain], (int)posX, (int)posY, null);	
		}
	}
	
	public boolean isOccupied() {
		return (occupiedTower != null);
	}
	
	//getters & setters
		public Tower getOccupiedTower() {return occupiedTower;}
		public void setOccupiedTower(Tower occupiedTower) {this.occupiedTower = occupiedTower;}
	
}
