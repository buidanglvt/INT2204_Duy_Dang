package TowerDefense.entities.terrains;

public class Road extends Terrain{
	
//Methods
	public Road(float posX, float posY, int imgId) {
		this.posX = posX;
		this.posY = posY;
		this.imgId = imgId;
	}
}
