package TowerDefense.entities.terrains;

import java.util.List;
import java.util.Queue;
import TowerDefense.entities.enemies.Enemy;

public class Spawner extends Road{
//Static fields
	static float spawnRate = 1; //times/s
	
//Attributes
	private Queue<Enemy> approachingEnemies;
	private long lastSpawningTime;
	
//Methods
	//Constructor
	public Spawner(float posX, float posY, int imgId) {
		super(posX, posY, imgId);
	}
	
	//Operations
		private boolean canSpawn() {
			return lastSpawningTime > 1000/spawnRate;
		}
		
		public void spawnEnemy(long elapsedTime, List<Enemy> enemiesOnField) {
			lastSpawningTime += elapsedTime;
			if (canSpawn()) {
				lastSpawningTime = 0;
				Enemy newEnemy = approachingEnemies.poll();
				newEnemy.setPosX(posX);
				newEnemy.setPosY(posY);
				enemiesOnField.add(newEnemy);
			}
		}

	
	//getter & setters
		public Queue<Enemy> getApproachingEnemies() {
			return approachingEnemies;
		}
		public void setApproachingEnemies(Queue<Enemy> approachingEnemies) {
			this.approachingEnemies = approachingEnemies;
		}
		
		public boolean hasApproachingEnemies() {
			return approachingEnemies != null && !approachingEnemies.isEmpty();
		}
}
