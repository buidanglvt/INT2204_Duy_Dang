package TowerDefense.entities.terrains;

import java.awt.Graphics;
import java.awt.Image;
import TowerDefense.entities.AbstractEntity;
import TowerDefense.entities.GameTile;

public abstract class Terrain extends AbstractEntity implements GameTile{
//Static fields
	public static Image[] TERRAIN_IMG = new Image[9];
	public static Image[] TERRAIN_MOUTAIN_IMG = new Image[8];
//Attributes
	protected int imgId;
	
//Methods
	@Override
	public void draw(Graphics renderer) {
		renderer.drawImage(TERRAIN_IMG[imgId], (int)posX, (int)posY, null);
	}
	//do nothing because terrain doesn't have to display info
	public void drawInfo(Graphics renderer) {}
}
