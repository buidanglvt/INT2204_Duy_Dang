package TowerDefense.entities.towers;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import TowerDefense.Config;
import TowerDefense.entities.Bullet;
import TowerDefense.sound.Sound;

public class MachineGun extends Tower {
//Attributes
	
//Methods
	//Constructor
	public MachineGun(float posX, float posY, int type) {
		super(posX, posY, type);
		bullet = new Bullet(Bullet.MACHINEGUN_BULLET, posX,posY, Bullet.MACHINE_BULLET_VELOCITY);
		range = MACHINEGUN_RANGE;
		if (type == 1) {
			fireRate = MACHINEGUN1_FIRE_RATE;
			damage = MACHINEGUN1_DAMAGE;
			price = MACHINEGUN1_PRICE;
		} else
		if (type == 2) {
			range = MACHINEGUN_RANGE;
			fireRate = MACHINEGUN2_FIRE_RATE;
			damage = MACHINEGUN2_DAMAGE;
			price = MACHINEGUN2_PRICE;
		}
		else System.out.println("Wrong tower type");
	}

	//Operations
	@Override
	public void draw(Graphics renderer) {
		Graphics2D renderer2d = (Graphics2D)renderer;
		//draw tower base
		renderer.drawImage(TOWER_BASE_IMG, (int)posX, (int)posY, null);
		//draw the rotated images by AimAngle
		AffineTransform asBefore = renderer2d.getTransform();
		renderer2d.rotate(AimAngle, posX+32, posY+32);
		if (type == 1)
			renderer.drawImage(MACHINEGUN1_IMG, (int)posX, (int)posY, null);
		else if (type == 2)
			renderer.drawImage(MACHINEGUN2_IMG, (int)posX, (int)posY, null);
		if (effectOn) 
			renderer2d.drawImage(MACHINEGUN_EFFECT_IMG, (int)posX, (int)posY-40, null);
		renderer2d.setTransform(asBefore);
		//draw bullet
		if (bullet.isVisible()) bullet.draw(renderer);
	}
	@Override
	public void drawInfo(Graphics renderer) {
		drawAttributes(renderer);
		renderer.drawString("Machine Gun "+type, Config.ATTRIBUTES_X, Config.NAME_Y);
		//draw range
		if (posX < Config.GRID_WIDTH && posY < Config.GRID_HEIGHT) {
		renderer.drawOval((int)(posX-range+32), (int)(posY-range+32), (int)range*2, (int)range*2);
		}
		//draw info image
		renderer.drawImage(TOWER_BASE_IMG,Config.INFO_IMAGE_X,Config.INFO_IMAGE_Y,128,128,null);
		if (type == 1)
		renderer.drawImage(MACHINEGUN1_IMG,Config.INFO_IMAGE_X,Config.INFO_IMAGE_Y,128,128,null);
		else if (type == 2)
		renderer.drawImage(MACHINEGUN2_IMG,Config.INFO_IMAGE_X,Config.INFO_IMAGE_Y,128,128,null);
		renderer.drawRect(Config.INFO_IMAGE_X, Config.INFO_IMAGE_Y, 128, 128);
	}
	@Override
	public void drawAttachedToMouse(Graphics renderer, int mouseX, int mouseY) {
		renderer.drawImage(TOWER_BASE_IMG, mouseX-32, mouseY-32, null);
		if (type == 1)
			renderer.drawImage(MACHINEGUN1_IMG, mouseX-32, mouseY-32, null);
		else if (type == 2)
			renderer.drawImage(MACHINEGUN2_IMG, mouseX-32, mouseY-32, null);
		//draw projection to grid
		if (mouseX < Config.GRID_WIDTH && mouseY < Config.GRID_HEIGHT) {
			int i = mouseY/64;
			int j = mouseX/64;
			if (Config.MAP[i][j] == 0 ) {
			renderer.drawOval(j*64-(int)range+32, i*64-(int)range+32, (int)range*2, (int)range*2);
			renderer.setColor(Config.TRANS_WHITE);
			renderer.fillRect(j*64, i*64, 64, 64);
			renderer.setColor(Color.BLACK);
			}
		}
	}

	@Override
	public Tower clone() {
		return new MachineGun(posX, posY, type);
	}
	
	@Override
	public void upgrade () {
        type = 2;
        fireRate = MACHINEGUN2_FIRE_RATE;
        damage = MACHINEGUN2_DAMAGE;
        price = MACHINEGUN2_PRICE;
    }
	
	@Override
    public int getUpgradeCost () {
		return MACHINEGUN2_PRICE - MACHINEGUN1_PRICE ;
	}

	@Override
	public void playSFX() {
		Sound.ShootMachineGun.play();
	}
}
