package TowerDefense.entities.towers;

import java.awt.Graphics;
import java.awt.Image;
import java.util.List;
import TowerDefense.Config;
import TowerDefense.entities.AbstractEntity;
import TowerDefense.entities.Bullet;
import TowerDefense.entities.GameTile;
import TowerDefense.entities.enemies.Enemy;
import TowerDefense.sound.Sound;

public abstract class Tower extends AbstractEntity implements GameTile{
//Static fields
	//Images
		public static Image TOWER_BASE_IMG;
		public static Image MINIGUN1_IMG;
		public static Image MINIGUN2_IMG;
		public static Image MINIGUN_EFFECT_IMG;
		public static Image MACHINEGUN1_IMG;
		public static Image MACHINEGUN2_IMG;
		public static Image MACHINEGUN_EFFECT_IMG;
		public static Image MISSILE_LAUNCHER1_IMG;
		public static Image MISSILE_LAUNCHER2_IMG;
		public static Image MISSILE_LAUNCHED_IMG;
	//MiniGun
		static float MINIGUN_RANGE = 160; // pixels
		static float MINIGUN1_FIRE_RATE = 2; // times/s
		static int MINIGUN1_DAMAGE = 50;
		static int MINIGUN1_PRICE = 100;
		static float MINIGUN2_FIRE_RATE = 3; // times/s
		static int MINIGUN2_DAMAGE = 70;
		static int MINIGUN2_PRICE = 200;
		
	//MachineGun
		static float MACHINEGUN_RANGE = 144; // pixels
		static float MACHINEGUN1_FIRE_RATE = 4; // times/s
		static int MACHINEGUN1_DAMAGE = 50;
		static int MACHINEGUN1_PRICE = 200;
		static float MACHINEGUN2_FIRE_RATE = 6; // times/s
		static int MACHINEGUN2_DAMAGE = 100;
		static int MACHINEGUN2_PRICE = 600;
		
	//MissileLauncher
		static float MISSILE_LAUNCHER_RANGE = 216; // pixels
		static float MISSILE_LAUNCHER_FIRE_RATE = 1; // times/s
		static int MISSILE_LAUNCHER1_DAMAGE = 300;
		static int MISSILE_LAUNCHER1_PRICE = 300;
		static int MISSILE_LAUNCHER2_DAMAGE = 1000;
		static int MISSILE_LAUNCHER2_PRICE = 1000;
	//Depreciation of tower's value
		public static final double DEPRECIATION = 0.75;
		
//Attributes
	//protected Queue<Enemy> targets; no longer in use
	protected Bullet bullet;
	protected float range;			//pixels
	protected float fireRate;		//times/s
	protected int damage;
	protected int price;
	protected int type;
	protected long lastAttackTime;	//milliseconds
	protected double AimAngle;		//radiant
	protected boolean effectOn;
	
//Methods
	//Constructor
	public Tower(float posX, float posY, int type) {
		this.posX = posX;
		this.posY = posY;
		this.type = type;
		lastAttackTime = 1000;
	}
	
	//Operations
		private boolean canAttack () {
			return (lastAttackTime >= 1000/fireRate);
		}
		
		/**
		 * @param enemies: a List of enemies
		 * Simply choose the enemies with lowest HP that was in range
		 */
		private Enemy chooseTarget(List<Enemy> enemies) {
			if (enemies.isEmpty()) 
				return null;
			Enemy target = null;
			for (Enemy e : enemies) {
				if (this.getDistance(e) < range) {
					if (target == null)
						target = e;
					else if (e.getHP() < target.getHP())
						target = e;
				}
			}
			return target;
		}
		
		/*
		 * @param elapsedTime
		 * move the bullet 
		 */
		private void moveBullet(long elapsedTime) {
			if (bullet.isVisible()) {
				//if bullet hits -> set bullet invisible and cause damage to enemy 
				if (this.getDistance(bullet) > this.getDistance(bullet.getTarget())) {
					bullet.setVisible(false);
					bullet.setHitEffectOn(true);
					bullet.setLastHitTime(0);
					bullet.getTarget().setHP(bullet.getTarget().getHP() - damage);
					if (this instanceof MissileLauncher) {
						Sound.Explosion.play();
					}
				}
				else 
					bullet.move(elapsedTime);
			}
			//if bullet has just been fired, turn on gun effect
			effectOn = bullet.isVisible() && this.getDistance(bullet) < 64;
			bullet.setLastHitTime(bullet.getLastHitTime() + elapsedTime);
		}
		
		/**
		 * @param elapsedTime
		 * Shoot the enemy on the peek of the Queue
		 */
		public void shootEnemy(List<Enemy> enemies, long elapsedTime) {
			//choose target
			Enemy target = chooseTarget(enemies) ;
			lastAttackTime += elapsedTime ;
			if (target != null) {
				//calculate AimAngle ~ radiant
				AimAngle = Math.atan2(posY-target.getPosY(), posX-target.getPosX()) - Math.PI/2;
				//shoot if canAttack
				if (canAttack()) {
					lastAttackTime = 0 ;
					//fire bullet toward enemy
					bullet.setPosX(posX);
					bullet.setPosY(posY);
					bullet.setTarget(target);
					bullet.setAimAngle(AimAngle);
					bullet.setVisible(true);
					playSFX();
				}
			}
			moveBullet(elapsedTime);
		}
		
		
		protected void drawAttributes(Graphics renderer) {
			renderer.setFont(Config.enityFont);
			renderer.drawString("Damage: "+damage, Config.ATTRIBUTES_X, Config.DAMAGE_Y);
			renderer.drawString("Range: "+range, Config.ATTRIBUTES_X, Config.RANGE_Y);
			renderer.drawString("Fire rate: "+fireRate, Config.ATTRIBUTES_X, Config.F_RATE_Y);
			renderer.drawString("Price: $"+price, Config.ATTRIBUTES_X, Config.PRICE_Y);
			//draw upgrade & sell buttons for tower in grid
			if (posX < Config.GRID_WIDTH && posY < Config.GRID_HEIGHT) {
			renderer.drawRect(Config.SELL_BUTTON_X, Config.SELL_BUTTON_Y, 80, 40);
			renderer.drawString("Sell", Config.SELL_BUTTON_X+10, Config.SELL_BUTTON_Y+30);
			if (type == 1) {
				renderer.drawRect(Config.UPGRADE_BUTTON_X, Config.UPGRADE_BUTTON_Y, 120, 40);
				renderer.drawString("Upgrade", 
				Config.UPGRADE_BUTTON_X+10, Config.UPGRADE_BUTTON_Y+30);
			}
			}
		}
		
		//abstract methods
		public abstract void upgrade() ;
	    public abstract int getUpgradeCost() ;
		public abstract void playSFX () ;
		public abstract void draw(Graphics renderer);
		public abstract void drawInfo(Graphics renderer);
		public abstract void drawAttachedToMouse(Graphics renderer, int mouseX, int mouseY);
		public abstract Tower clone();

	//getters & setters
		public float getRange() {return range;}
		public void setRange(float range) {this.range = range;}

		public float getFireRate() {return fireRate;}
		public void setFireRate(float fireRate) {this.fireRate = fireRate;}

		public int getDamage() {return damage;}
		public void setDamage(int damage) {this.damage = damage;}

		public int getPrice() {return price;}
		public void setPrice(int price) {this.price = price;}

		public double getAimAngle() {return AimAngle;}
		
		public int getType() {return type;}
		public void setType(int type) {this.type = type;}
		
		/** old abandoned code based on the idea of using Queue to select target
		 * @param enemies: a List of enemies
		 * Enqueue the enemy in range
		 * Dequeue the enemy that is out of range or dead
		public void updateTargets(List<Enemy> enemies) {
			for (Enemy e : enemies) {
				if (e.isAlive() && this.getDistance(e) < range) {
					targets.add(e);
				}
			}
			if (!targets.isEmpty()) {
				if (!targets.peek().isAlive() || this.getDistance(targets.peek()) > range ) {
					targets.poll();
				}
			}
		}
		 *AimAngle = Math.atan2(target.getPosY()-posY, target.getPosX()-posX);
		 * 
		*/
}
