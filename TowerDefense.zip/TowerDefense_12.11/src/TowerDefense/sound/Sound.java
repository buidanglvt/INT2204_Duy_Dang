package TowerDefense.sound;

import java.applet.Applet;
import java.applet.AudioClip;

public class Sound {
	public static final AudioClip BackGround = Applet.newAudioClip(Sound.class.getResource("Background.wav")) ;
	
    public static final AudioClip GameOver = Applet.newAudioClip(Sound.class.getResource("GameOver.wav")) ;
    
    public static final AudioClip Win = Applet.newAudioClip(Sound.class.getResource("Win.wav")) ;
    
    public static final AudioClip ShootMachineGun = Applet.newAudioClip(Sound.class.getResource("MachineGun.wav")) ;
    
    public static final AudioClip ShootMiniGun = Applet.newAudioClip(Sound.class.getResource("MiniGun.wav")) ;
    
    public static final AudioClip MissileLaunched = Applet.newAudioClip(Sound.class.getResource("MissileLaunched.wav")) ;
    
    public static final AudioClip PlacedTower = Applet.newAudioClip(Sound.class.getResource("PLaceTower.wav")) ;
    
    public static final AudioClip Click = Applet.newAudioClip(Sound.class.getResource("Click.wav")) ;
    
    public static final AudioClip Explosion = Applet.newAudioClip(Sound.class.getResource("Explosion.wav")) ;
}
